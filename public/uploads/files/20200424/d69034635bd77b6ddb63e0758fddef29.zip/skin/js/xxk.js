	function setTab(area,id) {
		var tabArea=document.getElementById(area);
		
		var contents=tabArea.childNodes;
		for(i=0; i<contents.length; i++) {
		if(contents[i].className=='tabcontent'){
			contents[i].style.display='none';}
		}
		document.getElementById(id).style.display='';
		
		var tabs=document.getElementById(area+'tabs').getElementsByTagName('div');
		for(i=0; i<tabs.length; i++) { tabs[i].className='seven_2_no'; }
		document.getElementById(id+'tab').className='seven_2_yes';
		document.getElementById(id+'tab').blur();
	}
	function setTabRole(area,id,dwlx) {
		var tabArea=document.getElementById(area);		
		var contents=tabArea.childNodes;
		for(i=0; i<contents.length; i++) {
			if(contents[i].className=='tabcontent'){
				contents[i].style.display='none';
			}
		}		
		document.getElementById('ee').style.display='';
		var tabs=document.getElementById(area+'tabs').getElementsByTagName('div');
		for(i=0; i<tabs.length; i++) { tabs[i].className='seven_2_no'; }
		document.getElementById(id+'tab').className='seven_2_yes';
		document.getElementById(id+'tab').blur();

		var p_id = $(window.frames["outsideFrame"].frames["leftFrame"].document).find("#p_id").val();
		
		var querystr = $(window.frames["outsideFrame"].frames["leftFrame"].document).find("#searchId").val();
		if(querystr=="�����뵥λ����"){
			querystr = "";
		}
		var search_url ='certQuery.do?method=kdMapLeftList&p_id=&querystr=&dwlx='+dwlx;
		window.outsideFrame.leftFrame.location.href=search_url;
		window.outsideFrame.mapFrame.showKd(p_id,dwlx,true);
		
	}