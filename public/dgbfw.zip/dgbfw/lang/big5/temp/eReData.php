<?php
if(!defined('InEmpireBak'))
{
	exit();
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=big5">
<title>��_�ƾ�</title>
<link href="images/css.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1">
  <tr> 
    <td>��m�G<a href="ReData.php">��_�ƾ�</a></td>
  </tr>
</table>
<br>
  <table width="70%" border="0" cellpadding="3" cellspacing="1" class="tableborder">
  <form name="ebakredata" method="post" action="phomebak.php" onsubmit="return confirm('�T�{�n��_�H');">
    <tr class="header"> 
      <td height="25" colspan="2">��_�ƾ� 
        <input name="phome" type="hidden" id="phome" value="ReData"></td>
    </tr>
    <tr bgcolor="#FFFFFF"> 
      <td width="34%" height="25">��_�ƾڷ��ؿ��G</td>
      <td width="66%" height="25"> 
        <?=$bakpath?>
        / 
        <input name="mypath" type="text" id="mypath" value="<?=$mypath?>"> <input type="button" name="Submit2" value="��ܥؿ�" onclick="javascript:window.open('ChangePath.php?change=1','','width=750,height=500,scrollbars=yes');"></td>
    </tr>
    <tr bgcolor="#FFFFFF"> 
      <td height="25" valign="top">�n�ɤJ���ƾڮw�G</td>
      <td height="25"> <select name="add[mydbname]" size="23" id="add[mydbname]" style="width:300">
          <?=$db?>
        </select></td>
    </tr>
    <tr bgcolor="#FFFFFF">
      <td height="25">��_�ﶵ�G</td>
      <td height="25">�C�ի�_���j�G 
        <input name="add[waitbaktime]" type="text" id="add[waitbaktime]" value="0" size="2">
        ��</td>
    </tr>
    <tr bgcolor="#FFFFFF"> 
      <td height="25" colspan="2"> <div align="left"> 
          <input type="submit" name="Submit" value="�}�l��_">
        </div></td>
    </tr>
	</form>
  </table>

</body>
</html>