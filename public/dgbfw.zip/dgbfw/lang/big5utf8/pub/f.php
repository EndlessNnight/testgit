<?php
$fun_r=array();
$fun_r=Array(
	'StartToBak'=>'初始化備份完成，正在進入表備份．．．．．．',
	'OneTableBakSuccOne'=>'備份 ',
	'OneTableBakSuccTwo'=>' 表完成，正在進入下一個表備份．．．．．．',
	'BakOneDataSuccess'=>'備份一組數據完成，正在進入下一組．．．．．．',
	'GotoDefaultDb'=>'正轉到默認的數據庫,請稍等......',
	'ConntConnectDb'=>'鏈接不上MYSQL，請設置好數據庫相關設置，<a href=SetDb.php><b><u>點擊此處</u></b></a>進行設置操作',
	'OneTableReSuccOne'=>'還原 ',
	'OneTableReSuccTwo'=>' 表完成，正在進入下一個表還原......',
	'ReOneDataSuccess'=>'一組數據恢復完成，正在進入下一組數據......',
	'BakSuccess'=>'恭喜您！備份完畢.',
	'ReDataSuccess'=>'恭喜您！數據還原完畢.',
	'TotalUseTime'=>'共計用時: ',
	'TimeHour'=>' 小時',
	'TimeMinute'=>' 分鐘',
	'TimeSecond'=>' 秒'
);
?>